from .celery import app as textSum

__all__ = ('textSum', )

devserver: {
    compress: true,
    disableHostCheck: true,
}
